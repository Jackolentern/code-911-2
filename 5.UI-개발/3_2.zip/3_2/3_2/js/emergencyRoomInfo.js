var rightSection = document.getElementById("rightSection");
var seoulMap = document.getElementById("seoulMap");
var gu;
var address;

//현재위치 박스 생성
function currentLocationBorder(){
  //자식노드 전체삭제
  rightSection.replaceChildren();
  //좌측버튼
  var leftButton = document.createElement("button");
  leftButton.id = 'previousButton';
  leftButton.className = "bi bi-chevron-double-left text-secondary";
  leftButton.addEventListener('click', previousGu);
  //우측버튼
  var rightButton = document.createElement("button");
  rightButton.id = 'nextButton';
  rightButton.className = "bi bi-chevron-double-right text-secondary";
  rightButton.addEventListener('click', nextGu);
  //현재위치
  var text1 = document.createElement("div");
  text1.textContent = ("현재위치");
  text1.style.fontSize = "1.2em "
  let gubox = document.createElement("div");
  gubox.id = 'present';
  gubox.style = "height: 25px; animation: fadeInUp 1s;"
  var currentLocation = document.createElement("div");
  currentLocation.style="background: rgb(255, 255, 255);"
  currentLocation.id = 'currentLocation';
  
  var hospital = document.createElement("div");
  hospital.id = 'hospital'
  currentLocation.appendChild(text1);
  currentLocation.appendChild(gubox);
  
  hospital.appendChild(leftButton);
  hospital.appendChild(currentLocation);
  hospital.appendChild(rightButton);
  rightSection.appendChild(hospital);
}
// 데이터 구별 input 반복 함수
function inputData(data){
  for(var i = 0; i<data.length; i++){
    if(i%2===0 || i===0){
      var hospitalBody = document.createElement("div");
      hospitalBody.style = "display: flex; justify-content: space-around; margin-top: 50px;  position: relative; animation: fadeInUp 1s;";
    }
    var row = document.createElement("div");
    row.style = "width: 200px; text-align: center; box-shadow: 5px 5px 3px #666; border-radius: 20px; border: 2px solid black; margin-bottom: 20px;";
    row.className = "align-botoom";
    
    var nameCell = document.createElement("p");
    nameCell.textContent = data[i].name;
    nameCell.style = "border-bottom: 1px solid black; height: 60px; margin: 0; font-weight: bold; font-size: 1.2em; padding: auto; display: flex; align-items: center; justify-content: center;";
    nameCell.className = "text-primary emrName";
    var telnumCell = document.createElement("p");
    telnumCell.innerHTML = '<span class="bi bi-telephone-fill">' + " " + data[i].telnum + "</span>";
    telnumCell.style = "height: 25px; line-height: 25px; margin: 0;";
    telnumCell.className = "text-secondary";
    var addressCell = document.createElement("p");
    addressCell.innerHTML = '<span class="bi bi-map-fill">' + " " +data[i].address + "</span>" + "<br>" + '  <button id="show" class="btn btn-primary">자세히</button>';;
    addressCell.style = "border-top: 1px solid black;";
    addressCell.className = "text-secondary emrAddress";
    row.appendChild(nameCell);
    row.appendChild(telnumCell);
    row.appendChild(addressCell);
    hospitalBody.appendChild(row);
    if(i-1===0 || (i-1)%2===0){
      rightSection.appendChild(hospitalBody);
    }else if(row!=null){
      rightSection.appendChild(hospitalBody);
    }
  }
}
// 구별 클릭함수
function clickSeoul(){
}
function clickDobong(){
  seoulMap.src = "img/seoulMap/Dobong.PNG"
  currentLocationBorder();
  gu = "도봉";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "의료법인한전의료재단한일병원", telnum: "02-901-3114", address: "서울특별시 도봉구 우이천로 308, 한일병원 (쌍문동)"}
  ]
  inputData(data);
};
function clickDongdaemun(){
  seoulMap.src = "img/seoulMap/Dongdaemun.PNG"
  currentLocationBorder();
  gu = "동대문";
  document.getElementById("present").innerText = gu;
};
function clickDongjak(){
  seoulMap.src = "img/seoulMap/Dongjak.PNG"
  currentLocationBorder();
  gu = "동작";
  document.getElementById("present").innerText = gu;
};
function clickEunpyeong(){
  seoulMap.src = "img/seoulMap/Eunpyeong.PNG"
  currentLocationBorder();
  gu = "은평";
  document.getElementById("present").innerText = gu;
};
function clickGangbuk(){
  seoulMap.src = "img/seoulMap/Gangbuk.PNG"
  currentLocationBorder();
  gu = "강북";
  document.getElementById("present").innerText = gu;
  let nullText = document.createElement("div");
  nullText.innerHTML = "강북구에는 응급실이 없습니다.<br>주변 지역을 클릭하면<br> 다른 응급실을 제공해드립니다.";
  nullText.className = "text-secondary text-center";
  nullText.style="font-size: 2em; margin-top: 50px; animation: fadeInUp 1s";
  rightSection.appendChild(nullText);
};
function clickGangdong(){
  seoulMap.src = "img/seoulMap/Gangdong.PNG"
  currentLocationBorder();
  gu = "강동";
  document.getElementById("present").innerText = gu;
};
function clickGangnam(){
  seoulMap.src = "img/seoulMap/Gangnam.PNG"
  currentLocationBorder();
  gu = "강남";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "	연세대학교의과대학강남세브란스병원", telnum: "02-2019-3114", address: "서울특별시 강남구 언주로 211, 강남세브란스병원 (도곡동)"},
    { name: "삼성서울병원", telnum: "02-3410-2114", address: "서울특별시 강남구 일원로 81 (일원동, 삼성의료원)"}
  ]
  inputData(data);
};
function clickGangseo(){
  seoulMap.src = "img/seoulMap/Gangseo.PNG"
  currentLocationBorder();
  gu = "강서";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "이화여자대학교의과대학부속서울병원", telnum: "02-6986-5119", address: "서울특별시 강서구 공항대로 260, 이화의대부속서울병원 (마곡동)"},
    { name: "부민병원", telnum: "02-2620-0119", address: "서울특별시 강서구 공항대로 389, 부민병원 (등촌동)"}
  ]
  inputData(data);
};
function clickGeumcheon(){
  seoulMap.src = "img/seoulMap/Geumcheon.PNG"
  currentLocationBorder();
  gu = "금천";
  document.getElementById("present").innerText = gu;
};
function clickGuro(){
  seoulMap.src = "img/seoulMap/Guro.PNG"
  currentLocationBorder();
  gu = "구로";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "구로성심병원", telnum: "02-2067-1515", address: "서울특별시 구로구 경인로 427, 구로성심병원 (고척동)"},
    { name: "고려대학교의과대학부속구로병원", telnum: "02-2626-1550", address: "서울특별시 구로구 구로동로 148, 고려대부속구로병원 (구로동)"}
  ]
  inputData(data);
};
function clickGwanak(){
  seoulMap.src = "img/seoulMap/Gwanak.PNG"
  currentLocationBorder();
  gu = "관악";
  document.getElementById("present").innerText = gu;
};
function clickGwangjin(){
  seoulMap.src = "img/seoulMap/Gwangjin.PNG"
  currentLocationBorder();
  gu = "광진";
  document.getElementById("present").innerText = gu;
};
function clickJongno(){
  seoulMap.src = "img/seoulMap/Jongno.PNG"
  currentLocationBorder();
  gu = "종로";
  document.getElementById("present").innerText = gu;
};
function clickJung(){
  seoulMap.src = "img/seoulMap/Jung.PNG"
  currentLocationBorder();
  gu = "중구";
  document.getElementById("present").innerText = gu;
};
function clickJungnang(){
  seoulMap.src = "img/seoulMap/Jungnang.PNG"
  currentLocationBorder();
  gu = "중랑";
  document.getElementById("present").innerText = gu;
};
function clickMapo(){
  seoulMap.src = "img/seoulMap/Mapo.PNG"
  currentLocationBorder();
  gu = "마포";
  document.getElementById("present").innerText = gu;
};
function clickNowon(){
  seoulMap.src = "img/seoulMap/Nowon.PNG"
  currentLocationBorder();
  gu = "노원";
  document.getElementById("present").innerText = gu;
};
function clickSeocho(){
  seoulMap.src = "img/seoulMap/Seocho.PNG"
  currentLocationBorder();
  gu = "서초";
  document.getElementById("present").innerText = gu;
};
function clickSeodaemun(){
  seoulMap.src = "img/seoulMap/Seodaemun.PNG"
  currentLocationBorder();
  gu = "서대문";
  document.getElementById("present").innerText = gu;
};
function clickSeongbuk(){
  seoulMap.src = "img/seoulMap/Seongbuk.PNG"
  currentLocationBorder();
  gu = "성북";
  document.getElementById("present").innerText = gu;
};
function clickSeongdong(){
  seoulMap.src = "img/seoulMap/Seongdong.PNG"
  currentLocationBorder();
  gu = "성동";
  document.getElementById("present").innerText = gu;
};
function clickSongpa(){
  seoulMap.src = "img/seoulMap/Songpa.PNG"
  currentLocationBorder();
  gu = "송파";
  document.getElementById("present").innerText = gu;
};
function clickYangcheon(){
  seoulMap.src = "img/seoulMap/Yangcheon.PNG"
  currentLocationBorder();
  gu = "양천";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "홍익병원", telnum: "02-2693-5555 ", address: "서울특별시 양천구 목동로 225, 홍익병원본관 (신정동)"},
    { name: "서울특별시서남병원", telnum: "1566-6688", address: "서울특별시 양천구 신정이펜1로 20 (신정동)"},
    { name: "이화여자대학교의과대학부속목동병원", telnum: "02-2650-5911", address: "	서울특별시 양천구 안양천로 1071 (목동)"}
  ]
  inputData(data);
};
function clickYeongdeungpo(){
  seoulMap.src = "img/seoulMap/Yeongdeungpo.PNG"
  currentLocationBorder();
  gu = "영등포";
  document.getElementById("present").innerText = gu;
};
function clickYongsan(){
  seoulMap.src = "img/seoulMap/Yongsan.PNG"
  currentLocationBorder();
  gu = "용산";
  document.getElementById("present").innerText = gu;
};
// 눌러서 다음구보기
function nextGu(){
  let thisGu = document.getElementById("present").innerText;
  let arr = [clickGangnam, clickGangdong, clickGangbuk, clickGangseo, clickGwanak, clickGwangjin, clickGuro, clickGeumcheon, clickNowon, clickDobong, clickDongdaemun, clickDongjak, clickMapo, clickSeodaemun, clickSeocho, clickSeongdong, clickSeongbuk, clickSongpa, clickYangcheon, clickYeongdeungpo, clickYongsan, clickEunpyeong, clickJongno, clickJung, clickJungnang];
  let guu = ["강남", "강동", "강북", "강서", "관악", "광진", "구로", "금천", "노원", "도봉", "동대문", "동작", "마포", "서대문", "서초", "성동", "성북", "송파", "양천", "영등포", "용산", "은평", "종로", "중구", "중랑"];
  for(let i=0; i<arr.length; i++){
    if(thisGu===null||thisGu===""||thisGu==="중랑"){
      arr[0](); // 첫 번째 함수 호출
      break;
    } else if(thisGu===guu[i]){
      arr[i+1](); // 현재 위치의 다음 함수 호출
      break;
    } 
  }
}
// 눌러서 이전구보기
function previousGu(){
  let thisGu = document.getElementById("present").innerText;
  let arr = [clickGangnam, clickGangdong, clickGangbuk, clickGangseo, clickGwanak, clickGwangjin, clickGuro, clickGeumcheon, clickNowon, clickDobong, clickDongdaemun, clickDongjak, clickMapo, clickSeodaemun, clickSeocho, clickSeongdong, clickSeongbuk, clickSongpa, clickYangcheon, clickYeongdeungpo, clickYongsan, clickEunpyeong, clickJongno, clickJung, clickJungnang];
  let guu = ["강남", "강동", "강북", "강서", "관악", "광진", "구로", "금천", "노원", "도봉", "동대문", "동작", "마포", "서대문", "서초", "성동", "성북", "송파", "양천", "영등포", "용산", "은평", "종로", "중구", "중랑"];
  for(let i=arr.length-1; i<arr.length; i--){
    if(thisGu===null||thisGu===""||thisGu==="강남"){
      arr[24](); // 마지막 함수 호출
      break;
    } else if(thisGu===guu[i]){
      arr[i-1](); // 현재 위치의 이전 함수 호출
      break;
    } 
  }
}
//서울 이미지맵 반응형 웹
$(document).ready(function() {
  $('img[usemap]').rwdImageMaps();
});

function show() {
  document.querySelector(".background").className = "background show";
}

function close() {
  document.querySelector(".background").className = "background";
}

// 버튼 클릭 이벤트 등록
document.addEventListener('click', function(event) {
  if (event.target.id === 'show') {
    // 부모 노드에서 주소를 가져옴
    var parent = event.target.closest(".align-botoom");
    var emrName = parent.querySelector(".emrName").textContent.trim();
    var emrAddress = parent.querySelector(".emrAddress").textContent.slice(0, -3);
    document.getElementById("emrName").innerText = emrName;
    document.getElementById("emrAddress").innerText = emrAddress;
    
    // Kakao Maps 초기화
    var mapContainer = document.getElementById('map');
    var mapOption = {
      center: new kakao.maps.LatLng(33.450701, 126.570667),
      level: 3
    };
    var map = new kakao.maps.Map(mapContainer, mapOption);

    // 주소-좌표 변환 객체 생성
    var geocoder = new kakao.maps.services.Geocoder();

    // 주소로 좌표 검색
    geocoder.addressSearch(emrAddress, function(result, status) {
      if (status === kakao.maps.services.Status.OK) {
        var coords = new kakao.maps.LatLng(result[0].y, result[0].x);
        var marker = new kakao.maps.Marker({
          map: map,
          position: coords
        });
        var infowindow = new kakao.maps.InfoWindow({
          content: '<div style="width:150px;text-align:center;padding:6px 0;">'+emrName+'</div>'
        });
        infowindow.open(map, marker);
        map.setCenter(coords);
      }
    });
    // 지도 크기 조절
    var minZoomLevel = 2;
    var maxZoomLevel = 4;

    // setMinLevel() 메서드를 사용하여 최소 지도 확대 수준 설정
    map.setMinLevel(minZoomLevel);
    map.setMaxLevel(maxZoomLevel);
    show(); // 모달 표시
  }
});

document.querySelector("#close").addEventListener("click", close);

var mapContainer = document.getElementById('map'), // 지도를 표시할 div  
                mapOption = { 
                    center: new kakao.maps.LatLng(37.5642135, 127.0016985), // 지도의 중심좌표
                    level: 6 // 지도의 확대 레벨

                };
            
            var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다
            // 지도 크기 조절
            var minZoomLevel = 4;
            var maxZoomLevel = 9;

            // setMinLevel() 메서드를 사용하여 최소 지도 확대 수준 설정
            map.setMinLevel(minZoomLevel);
            map.setMaxLevel(maxZoomLevel);

            

            // 마커를 표시할 위치와 title 객체 배열입니다 
            var positions = [
                {
                    //1
                    title: '가톨릭대학교여의도성모병원', 
                    latlng: new kakao.maps.LatLng(37.51827234, 126.9367313)
                },
                {
                    //2
                    title: '가톨릭대학교은평성모병원', 
                    latlng: new kakao.maps.LatLng(37.63360841, 126.9161505)
                },
                {
                    //3
                    title: '강동경희대학교의대병원',
                    latlng: new kakao.maps.LatLng(37.55204593, 127.1570848)
                },

                {
                    //4
                    title: '강북삼성병원',
                    latlng: new kakao.maps.LatLng(37.56849763, 126.9679381)
                },
                {
                    //5
                    title: '건국대학교병원',
                    latlng: new kakao.maps.LatLng(37.54084479, 127.0721229)
                },
                {
                    //6
                    title: '경찰병원',
                    latlng: new kakao.maps.LatLng(37.49641321, 127.1234879)
                },
                {
                    //7
                    title: '경희대학교병원',
                    latlng: new kakao.maps.LatLng(37.59387655, 127.0518322)
                },
                {
                    //8
                    title: '고려대학교의과대학부속구로병원',
                    latlng: new kakao.maps.LatLng(37.49211115, 126.8847449)
                },
                {
                    //9
                    title: '구로성심병원',
                    latlng: new kakao.maps.LatLng(37.49964579, 126.8663604)
                },
                {
                    //10
                    title: '국립중앙의료원',
                    latlng: new kakao.maps.LatLng(37.56733956, 127.0057954)
                },
                {
                    //11
                    title: '노원을지대학교병원',
                    latlng: new kakao.maps.LatLng(37.63644293, 127.0700028)
                },
                {
                    //12
                    title: '녹색병원',
                    latlng: new kakao.maps.LatLng(37.58362084, 127.0860555)
                },
                {
                    //13
                    title: '대림성모병원',
                    latlng: new kakao.maps.LatLng(37.49068925, 126.9071695)
                },
                {
                    //14
                    title: '명지성모병원',
                    latlng: new kakao.maps.LatLng(37.49385071, 126.8992545)
                },
                {
                    //15
                    title: '부민병원',
                    latlng: new kakao.maps.LatLng(37.55694089, 126.8509495)
                },
                {
                    //16
                    title: '삼성서울병원',
                    latlng: new kakao.maps.LatLng(37.48851613, 127.0866825)
                },
                {
                    //17
                    title: '삼육서울병원',
                    latlng: new kakao.maps.LatLng(37.587992, 127.0653288)
                },
                {
                    //18
                    title: '서울대학교병원',
                    latlng: new kakao.maps.LatLng(37.57966609, 126.9989631)
                },
                {
                    //19
                    title: '서울성심병원',
                    latlng: new kakao.maps.LatLng(37.58419129, 127.0498381)
                },
                {
                    //20
                    title: '서울적십자병원',
                    latlng: new kakao.maps.LatLng(37.56715536, 126.9669986)
                },
                {
                    //21
                    title: '서울특별시동부병원',
                    latlng: new kakao.maps.LatLng(37.57539886, 127.0314026)
                },
                {
                    //22
                    title: '서울특별시보라매병원',
                    latlng: new kakao.maps.LatLng(37.4937184, 126.9240488)
                },
                {
                    //23
                    title: '서울특별시서남병원',
                    latlng: new kakao.maps.LatLng(37.51201936, 126.8331299)
                },
                {
                    //24
                    title: '서울특별시서울의료원',
                    latlng: new kakao.maps.LatLng(37.61286932, 127.0980911)
                },
                {
                    //25
                    title: '성심의료재단강동성심병원',
                    latlng: new kakao.maps.LatLng(37.53598408, 127.1352635)
                },
                {
                    //26
                    title: '성애의료재단성애병원',
                    latlng: new kakao.maps.LatLng(37.51205045, 126.9223673)
                },
                {
                    //27
                    title: '세란병원',
                    latlng: new kakao.maps.LatLng(37.57534017, 126.9577072)
                },
                {
                    //28
                    title: '순천향대학교 부속 서울병원',
                    latlng: new kakao.maps.LatLng(37.53384172, 127.004418)
                },
                {
                    //29
                    title: '연세대학교의과대학강남세브란스병원',
                    latlng: new kakao.maps.LatLng(37.49280698, 127.0463125)
                },
                {
                    //30
                    title: '연세대학교의과대학세브란스병원',
                    latlng: new kakao.maps.LatLng(37.56211711, 126.9408277)
                },
                {
                    //31
                    title: '의료법인동신의료재단 동신병원',
                    latlng: new kakao.maps.LatLng(37.58110428, 126.9365831)
                },
                {
                    //32
                    title: '의료법인서울효천의료재단 에이치플러스양지병원',
                    latlng: new kakao.maps.LatLng(37.48427507, 126.9325392)
                },
                {
                    //33
                    title: '의료법인청구성심병원',
                    latlng: new kakao.maps.LatLng(37.62079154, 126.919554)
                },
                {
                    //34
                    title: '의료법인풍산의료재단동부제일병원',
                    latlng: new kakao.maps.LatLng(37.60067565, 127.1090292)
                },
                {
                    //35
                    title: '의료법인한전의료재단한일병원',
                    latlng: new kakao.maps.LatLng(37.6461157, 127.0290242)
                },
                {
                    //36
                    title: '이화여자대학교의과대학부속목동병원',
                    latlng: new kakao.maps.LatLng(37.53654283, 126.886216)
                },
                {
                    //37
                    title: '이화여자대학교의과대학부속서울병원',
                    latlng: new kakao.maps.LatLng(37.55726115, 126.8362659)
                },
                {
                    //38
                    title: '인제대학교상계백병원',
                    latlng: new kakao.maps.LatLng(37.64858127, 127.0631162)
                },
                {
                    //39
                    title: '재단법인아산사회복지재단 서울아산병원',
                    latlng: new kakao.maps.LatLng(37.52656397, 127.1082383)
                },
                {
                    //40
                    title: '중앙대학교병원',
                    latlng: new kakao.maps.LatLng(37.50707428, 126.9607938)
                },
                {
                    //41
                    title: '학교법인 고려중앙학원 고려대학교의과대학부속병원(안암병원)',
                    latlng: new kakao.maps.LatLng(37.58715608, 127.0264709)
                },
                {
                    //42
                    title: '학교법인가톨릭학원가톨릭대학교서울성모병원',
                    latlng: new kakao.maps.LatLng(37.5018008, 127.0047273)
                },
                {
                    //43
                    title: '한국보훈복지의료공단 중앙보훈병원',
                    latlng: new kakao.maps.LatLng(37.5282209, 127.1467189)
                },
                {
                    //44
                    title: '한국원자력의학원원자력병원',
                    latlng: new kakao.maps.LatLng(37.62881598, 127.0826932)
                },
                {
                    //45
                    title: '한림대학교강남성심병원',
                    latlng: new kakao.maps.LatLng(37.49324929, 126.9086725)
                },
                {
                    //46
                    title: '한양대학교병원',
                    latlng: new kakao.maps.LatLng(37.55994453, 127.0448828)
                },
                {
                    //47
                    title: '혜민병원',
                    latlng: new kakao.maps.LatLng(37.53531566, 127.0836013)
                },
                {
                    //48
                    title: '홍익병원',
                    latlng: new kakao.maps.LatLng(31.52844141, 126.863664)
                },
                {
                    //49
                    title: '희명병원',
                    latlng: new kakao.maps.LatLng(37.45567063, 126.9005625)
                }
            ];
            
            //마커 이미지 설정
            var imageSrc = "img/emergencyMarker.png";
            var imageSize = new kakao.maps.Size(24, 35);
            var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

            // 지역별 마커 찍기
            // 1.가톨릭대학교여의도성모병원
            var hospital0 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[0].latlng, // 마커를 표시할 위치
                title: positions[0].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 2.가톨릭대학교은평성모병원
            var hospital1 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[1].latlng, // 마커를 표시할 위치
                title: positions[1].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 3.강동경희대학교의대병원
            var hospital2 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[2].latlng, // 마커를 표시할 위치
                title: positions[2].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 4.강북삼성병원
            var hospital3 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[3].latlng, // 마커를 표시할 위치
                title: positions[3].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });

            // 5.건국대학교병원
            var hospital4 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[4].latlng, // 마커를 표시할 위치
                title: positions[4].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 6.경찰병원
            var hospital5 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[5].latlng, // 마커를 표시할 위치
                title: positions[5].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 7.경희대학교병원
            var hospital6 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[6].latlng, // 마커를 표시할 위치
                title: positions[6].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 8.고려대학교의과대학부속구로병원
            var hospital7 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[7].latlng, // 마커를 표시할 위치
                title: positions[7].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 9.구로성심병원
            var hospital8 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[8].latlng, // 마커를 표시할 위치
                title: positions[8].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 10.국립중앙의료원
            var hospital9 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[9].latlng, // 마커를 표시할 위치
                title: positions[9].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 11.노원을지대학교병원
            var hospital10 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[10].latlng, // 마커를 표시할 위치
                title: positions[10].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 12.녹색병원
            var hospital10 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[11].latlng, // 마커를 표시할 위치
                title: positions[11].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 13.대림성모병원
            var hospital12 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[12].latlng, // 마커를 표시할 위치
                title: positions[12].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 14.명지성모병원
            var hospital13 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[13].latlng, // 마커를 표시할 위치
                title: positions[13].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 15.부민병원
            var hospital14 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[14].latlng, // 마커를 표시할 위치
                title: positions[14].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 16.삼성서울병원
            var hospital15 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[15].latlng, // 마커를 표시할 위치
                title: positions[15].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 17.삼육서울병원
            var hospita16 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[16].latlng, // 마커를 표시할 위치
                title: positions[16].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 18.서울대학교병원
            var hospital17 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[17].latlng, // 마커를 표시할 위치
                title: positions[17].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 19.서울성심병원
            var hospital18 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[18].latlng, // 마커를 표시할 위치
                title: positions[18].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 20.서울적십자병원
            var hospital19 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[19].latlng, // 마커를 표시할 위치
                title: positions[19].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 21.서울특별시동부병원
            var hospita20 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[20].latlng, // 마커를 표시할 위치
                title: positions[20].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 22.서울특별시보라매병원
            var hospital21 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[21].latlng, // 마커를 표시할 위치
                title: positions[21].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 23.서울특별시서남병원
            var hospital22 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[22].latlng, // 마커를 표시할 위치
                title: positions[22].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 24.서울특별시서울의료원
            var hospital23 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[23].latlng, // 마커를 표시할 위치
                title: positions[23].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 25.성심의료재단강동성심병원
            var hospital24 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[24].latlng, // 마커를 표시할 위치
                title: positions[24].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 26.성애의료재단성애병원
            var hospital25 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[25].latlng, // 마커를 표시할 위치
                title: positions[25].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 27.세란병원
            var hospital26 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[26].latlng, // 마커를 표시할 위치
                title: positions[26].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 28.순천향대학교 부속 서울병원
            var hospital27 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[27].latlng, // 마커를 표시할 위치
                title: positions[27].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 29.연세대학교의과대학강남세브란스병원
            var hospital28 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[28].latlng, // 마커를 표시할 위치
                title: positions[28].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 30.연세대학교의과대학세브란스병원
            var hospital29 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[29].latlng, // 마커를 표시할 위치
                title: positions[29].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 31.의료법인동신의료재단 동신병원
            var hospital30 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[30].latlng, // 마커를 표시할 위치
                title: positions[30].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 32.의료법인서울효천의료재단 에이치플러스양지병원
            var hospital31 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[31].latlng, // 마커를 표시할 위치
                title: positions[31].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 33.의료법인청구성심병원
            var hospital32 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[32].latlng, // 마커를 표시할 위치
                title: positions[32].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 34.의료법인풍산의료재단동부제일병원
            var hospital33 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[33].latlng, // 마커를 표시할 위치
                title: positions[33].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 35.의료법인한전의료재단한일병원
            var hospital34 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[34].latlng, // 마커를 표시할 위치
                title: positions[34].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 36.이화여자대학교의과대학부속목동병원
            var hospital35 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[35].latlng, // 마커를 표시할 위치
                title: positions[35].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 37.이화여자대학교의과대학부속서울병원
            var hospital36 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[36].latlng, // 마커를 표시할 위치
                title: positions[36].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 38.인제대학교상계백병원
            var hospital37 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[37].latlng, // 마커를 표시할 위치
                title: positions[37].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 39.재단법인아산사회복지재단 서울아산병원
            var hospital38 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[38].latlng, // 마커를 표시할 위치
                title: positions[38].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 40.중앙대학교병원
            var hospital39 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[39].latlng, // 마커를 표시할 위치
                title: positions[39].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 41.학교법인 고려중앙학원 고려대학교의과대학부속병원(안암병원)
            var hospital40 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[40].latlng, // 마커를 표시할 위치
                title: positions[40].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 42.학교법인가톨릭학원가톨릭대학교서울성모병원
            var hospital41 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[41].latlng, // 마커를 표시할 위치
                title: positions[41].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 43.한국보훈복지의료공단 중앙보훈병원
            var hospital42 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[42].latlng, // 마커를 표시할 위치
                title: positions[42].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 44.한국원자력의학원원자력병원
            var hospital43 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[43].latlng, // 마커를 표시할 위치
                title: positions[43].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 45.한림대학교강남성심병원
            var hospital44 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[44].latlng, // 마커를 표시할 위치
                title: positions[44].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 46.한양대학교병원
            var hospital45 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[45].latlng, // 마커를 표시할 위치
                title: positions[45].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 47.혜민병원
            var hospital46 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[46].latlng, // 마커를 표시할 위치
                title: positions[46].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 48.홍익병원
            var hospital47 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[47].latlng, // 마커를 표시할 위치
                title: positions[47].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 49.희명병원
            var hospital48 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[48].latlng, // 마커를 표시할 위치
                title: positions[48].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });     
            // 지도에 마커와 인포윈도우를 표시하는 함수입니다
            function displayMarker(locPosition, message) {
            
                // 마커를 생성합니다
                var marker = new kakao.maps.Marker({  
                    map: map, 
                    position: locPosition
                }); 
                
                var iwContent = message, // 인포윈도우에 표시할 내용
                    iwRemoveable = true;
            
                // 인포윈도우를 생성합니다
                var infowindow = new kakao.maps.InfoWindow({
                    content : iwContent,
                    removable : iwRemoveable
                });
                
                // 인포윈도우를 마커위에 표시합니다 
                infowindow.open(map, marker);
                
                // 지도 중심좌표를 접속위치로 변경합니다
                map.setCenter(locPosition);      
            }   

            function findMyLocation() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function (position) {
                        var lat = position.coords.latitude,
                            lon = position.coords.longitude;
    
                        var locPosition = new kakao.maps.LatLng(lat, lon),
                            message = '<div style="padding:5px;">현재 위치</div>';
    
                        displayMarker(locPosition, message);
                    });
                } else {
                    var locPosition = new kakao.maps.LatLng(33.450701, 126.570667),
                        message = 'geolocation을 사용할수 없어요..';
    
                    displayMarker(locPosition, message);
                }
            }

            findMyLocation();

            

    // 마커에 클릭 이벤트 등록
    kakao.maps.event.addListener(hospital3, 'click', function() {
        changeBoard(0);
        drawChart(0);
    }); // 강북삼성병원
    kakao.maps.event.addListener(hospital19, 'click', function() {
        changeBoard(1);
        drawChart(1);
    }); // 서울적십자병원
    
    kakao.maps.event.addListener(hospital26, 'click', function() {
        changeBoard(2);
        drawChart(2);
    }); // 세란병원
    
    kakao.maps.event.addListener(hospital29, 'click', function() {
        changeBoard(3);
        drawChart(3);
    }); // 연세대학교의과대학세브란스병원

    kakao.maps.event.addListener(hospital30, 'click', function() {
        changeBoard(4);
        drawChart(4);
    }); // 의료법인동신의료재단 동신병원 

    // 내 위치 버튼을 클릭하면 화면에 내 위치 표시
    var myLocationButton = document.querySelector("#myLocation");

        myLocationButton.addEventListener('click', findMyLocation);
        
    
    // 응급실 데이터 배열
    var hospitalData = [
        {name: "강북삼성병원", hvgc: 95, hvoc: 0, hperyn: 13, hvec: 13,
         emReceive1: "", emReceive2: "", emReceive3: ""},

        {name: "서울적십자병원", hvgc: 82, hvoc: 5, hperyn: 10, hvec: 4,
         emReceive1: "", emReceive2: "", emReceive3: ""},
        
        {name: "세란병원", hvgc: 35, hvoc: 2, hperyn: 10, hvec: 9,
        emReceive1: "응급", emReceive2: "응급실", emReceive3: "ct 촬영 불가."},

        {name: "연세대학교의과대학세브란스병원", hvgc: 38, hvoc: 2, hperyn: 41, hvec: 22,
        emReceive1: "응급", emReceive2: "응급실", emReceive3: "격리진료구역병상 성인/소아 구분 신고 체계 미비로 실제 정보와 다를 수 있음."},

        {name: "의료법인동신의료재단 동신병원", hvgc: 100, hvoc: 0, hperyn: 41, hvec: -36,
        emReceive1: "", emReceive2: "", emReceive3: ""}
    ]

    function changeBoard(index) {
        var hospitalName = document.querySelector("#hospital-name");
        var confusedLevel = document.querySelector("#confused-level");
        var confusedStep = document.querySelector("#confused-step");
        var hvgc = document.querySelector("#used-admiss");
        var hvoc = document.querySelector("#used-surgery");
        var emReceive1 = document.querySelector("#em-receive1");
        var emReceive2 = document.querySelector("#em-receive2");
        var emReceive3 = document.querySelector("#em-receive3");

     // 응급 메시지가 없을 경우: 전달 내용 X, 응급 메세지가 있을 경우: 내용 그대로 출력
    if (hospitalData[index].emReceive1 === "") {
        emReceive1.textContent = "전달 내용 X";
    } else {
        emReceive1.textContent = hospitalData[index].emReceive1;
    }

    if (hospitalData[index].emReceive2 === "") {
        emReceive2.textContent = "전달 내용 X";
    } else {
        emReceive2.textContent = hospitalData[index].emReceive2;
    }

    if (hospitalData[index].emReceive3 === "") {
        emReceive3.textContent = "전달 내용 X";
    } else {
        emReceive3.textContent = hospitalData[index].emReceive3;
    }

    // 응급실 혼잡율에 따른 confusedLevel 색 변경 및 confusedStep style 설정
    if (hospitalData[index].hvec / hospitalData[index].hperyn == 1) {
        confusedLevel.style.color = "red";
        confusedStep.textContent = "심각";
    }
      else if (hospitalData[index].hvec / hospitalData[index].hperyn > 0.8 && hospitalData[index].hvec / hospitalData[index].hperyn < 1) {
        confusedLevel.style.color = "green";
        confusedStep.textContent = "여유";
    } else if (hospitalData[index].hvec / hospitalData[index].hperyn > 0.5 && hospitalData[index].hvec / hospitalData[index].hperyn < 0.79) {
        confusedLevel.style.color = "orange";
        confusedStep.textContent = "보통";
    } else {
        confusedLevel.style.color = "red";
        confusedStep.textContent = "심각";
    }

    // 병원 이름, 입원실과 수술실의 가용 병상 수 표시
    hospitalName.textContent = hospitalData[index].name;
    hvgc.textContent = hospitalData[index].hvgc;
    hvgc.style.fontWeight = 'bold';
    hvoc.textContent = hospitalData[index].hvoc;
    hvoc.style.fontWeight = 'bold';

    // confusedStep style 설정
    confusedStep.style.fontWeight = "bold";
    confusedStep.style.color = confusedLevel.style.color;
    }

    var myChart;

    function drawChart(index) {
        var emergencyRoom = hospitalData[index].hperyn - hospitalData[index].hvec;

        if(emergencyRoom ==0) {
            emergencyRoom = hospitalData[index].hvec;
        }

        var data = {
            labels: ['대기 환자', '기존 병상수'],
            datasets: [{
                label: '(응급실)대기 환자/기존 병상수',
                data: [emergencyRoom, hospitalData[index].hperyn],
                backgroundColor: ['red', 'green'],
            }]
        };

        var ctx = document.getElementById('statusChart').getContext('2d');

        // 이전 차트 파괴
        if (myChart) {
            myChart.destroy();
        }

        // 새로운 차트 생성
        myChart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {}
        });
    }
// 첫번재 그래프 데이터
const labels = ['2016', '2017', '2018', '2019'];
var data = {
  labels: labels,
  datasets: [
    {
      label: "필요응급실",
      data: [167,168,167,167],
      borderColor: 'rgb(255,165,0)',
      backgroundColor: 'rgb(255,165,0,0.5)'
    },
    {
      label: "현재응급실",
      data: [51,51,48,50],
      borderColor: 'rgb(102,144,255)',
      backgroundColor: 'rgb(102,144,255,0.5)',
    }
  ]
};
// 첫번째 그래프
var ctx = document.getElementById('myChart1').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'bar',
  data: data,
  options: {
    indexAxis: 'y',
    // Elements options apply to all of the options unless overridden in a dataset
    // In this case, we are setting the border of each horizontal bar to be 2px wide
    elements: {
      bar: {
        borderWidth: 2,
      }
    },
    responsive: true,
    plugins: {
      legend: {
        position: 'right',
      },
      title: {
        display: true,
        text: '서울시 연도별 응급실 수 그래프'
      }
    }
  }
});

// 응급실수 버튼
function emergencyRoom(){
  if(myChart.data.datasets[1]==null){
    myChart.data.datasets.push(popData);
  }
  myChart.data.datasets[0].label = "필요응급실";
  myChart.data.datasets[0].data = [167,168,167,167];
  myChart.data.datasets[0].borderColor = 'rgb(255, 165, 0)';
  myChart.data.datasets[0].backgroundColor = 'rgb(255, 165, 0,0.5)'
  myChart.data.datasets[1].label = "현재응급실";
  myChart.data.datasets[1].data = [51,51,48,50];
  myChart.options.plugins.title.text = "서울시 연도별 응급실 수 그래프";

  document.querySelector(".chart1Text").innerHTML = '<h4 id="text" class="chart1Text">이 그래프는 응급실의 현재 개수와 인구수에 비례해 필요한 응급실 개수를 표시한 그래프입니다.<br>그래프와 병상포화지수를 통해 응급실 상태를 예상할수 있습니다.<p class="text-secondary" style="font-size: 0.7em;">응급실의 개수는 국내 기준이 없어 톈진시 기준을 사용하였습니다.</p></h4>'

  myChart.update();
}
// 병상포화지수 버튼
function saturation () {
  myChart.data.datasets[0].label = "병상포화지수";
  myChart.data.datasets[0].data = [58.14166424, 55.81499949, 64.09502703, 61.35209813];
  myChart.data.datasets[0].borderColor = 'rgb(202, 0, 20)';
  myChart.data.datasets[0].backgroundColor = 'rgb(202, 0, 0, 0.5)'
  myChart.options.plugins.title.text = "병상포화지수 그래프";

  if(myChart.data.datasets[1]!=null){
    popData = myChart.data.datasets.pop();
  }

  document.querySelector(".chart1Text").innerHTML = '이 그래프는 년도별 병상포화지수를 나타낸 그래프 입니다<p class="text-secondary" style="font-size: 0.5em; padding-top: 50px;">병상포화지수(%)는(내원 환자수×평균 재실시간)/(기준병상수×월별일자수×24시간)×100</p>'

  myChart.update();
}

// 두번쨰 그래프
var indexCount = 0;
// 기본 데이터
const hbData = [
  { x: 1171, y: 64.09503 }
];
// 추가 데이터
const otherData = [
  { x: 1411, y: 53.19297  }, 
  { x: 1651, y: 45.46049 }, { x: 1891, y: 39.69079 }, 
  { x: 2131, y: 35.22068 }, { x: 2371, y: 31.65554 }, 
  { x: 2611, y: 28.74580 }, { x: 2851, y: 26.32595 }
];

// 데이터로 회귀선 생성
function linearRegression(x, y) {
  const n = x.length;
  let sumX = 0, sumY = 0, sumXY = 0, sumXSquare = 0;

  for (let i = 0; i < n; i++) {
    sumX += x[i];
    sumY += y[i];
    sumXY += x[i] * y[i];
    sumXSquare += x[i] ** 2;
  }

  const slope = (n * sumXY - sumX * sumY) / (n * sumXSquare - sumX ** 2);
  const intercept = (sumY - slope * sumX) / n;

  return { slope, intercept };
}

const { slope, intercept } = linearRegression(hbData.map(d => d.x), hbData.map(d => d.y));

//회귀선 업데이트
function updateRegressionLine() {
  const { slope, intercept } = linearRegression(hbData.map(d => d.x), hbData.map(d => d.y));
  correlationChart.data.datasets[1].data = hbData.map(d => ({ x: d.x, y: slope * d.x + intercept }));
}

const hbCtx = document.getElementById('myChart2').getContext('2d');

const correlationChart = new Chart(hbCtx, {
  type: 'scatter',
  data: {
    datasets: [{
      label: '병상수/병상포화지수',
      data: hbData,
      backgroundColor: 'rgba(17, 152, 247, 0.6)',
      borderColor: 'rgba(17, 152, 247, 1)',
      pointRadius: 5
    }, {
      type: 'line',
      label: '회귀선',
      data: hbData.map(d => ({ x: d.x, y: slope * d.x + intercept })),
      borderColor: 'rgba(245, 53, 133, 0.6)',
      backgroundColor: 'rgba(245, 53, 133, 1)',
      fill: false,
      pointRadius: 0,
      showLine: true,
      lineTension: 0
    }]
  },
  options: {
    scales: {
      x: {
        title: {
          display: true,
          text: '병상수'
        },
      },
      y: {
        title: {
          display: true,
          text: '병상포화지수'
        }
      }
    }
  }
});
// 데이터pop
function minusData(){
  if(indexCount!=0){
    hbData.pop();
    updateRegressionLine();
    correlationChart.update();
    indexCount--;
  }
}
// 데이터push
function plusData(){
  for(let i=0; i<otherData.length; i++){
    if(indexCount===i){
      hbData.push(otherData[i]);
      updateRegressionLine();
      correlationChart.update();
      indexCount++;
      break;
    }
  }

}
// 3번째 그래프
var data = {
        labels: ['2006','2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022'],
        datasets: [{
        label: '서울시 인구수 변화율',
        data: [0,4.00980040,0.32865781,0.07667343,1.06455903,-0.44133359,-0.82011448,-0.52067403,-0.17772336,-0.69872559,-0.90395020,-0.77888628,-0.74049499,-0.38433344,-0.99785406,-1.76631466,-0.70211391],
        fill: false,
        borderColor: 'rgb(57, 120, 207)',
        tension: 0.1
        }
        
      ]
    };
var ctx = document.getElementById('myChart3').getContext('2d');
var myChart3 = new Chart(ctx, {
type: 'line', 
data: data,
options: {}
});

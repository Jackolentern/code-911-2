// 스크롤시 네비게이션 바 투명도 증가
const menu = document.querySelector('#menu');
const menuHeight = menu.getBoundingClientRect().height;
document.addEventListener('scroll', () => {
    if (window.scrollY > menuHeight) {
        document.querySelector("nav").style.background = "rgb(255, 255, 255, 0.8)";
    } else {
        document.querySelector("nav").style.background = "white";
    }
});

//시도 좌표 geojson import
import geojson from './sido.json' assert{ type: "json" };

//testData.json import
import testData from './erData.json' assert{ type: "json" };

//응급실 차트 관련 변수 선언
let erData = testData;
var targetRegion = "";
var initialValue = [];
var addtionalValue = [];
var key = Object.getOwnPropertyNames(erData[0]);
key.shift();

//응급실 차트 전국 value setting
erData.forEach((val) => {
    if (val.region == "전국") {
        initialValue.push(val.within60);
        initialValue.push(val.inside);
        initialValue.push(val.within30);
    }
})

//응급실 차트 변수 선언
var ctx1 = document.getElementById('erChart1').getContext('2d');
var ctx2 = document.getElementById('erChart2').getContext('2d');
var myChart1;
var myChart2;

// 초기 데이터셋
var initialData = {
    labels: ["60분 내 응급실 이용률", "관내 응급실 이용률", "응급실 30분 내 접근 불가능한 인구 비율"],
    datasets: [{
        label: '전국',
        backgroundColor: 'rgba(75, 192, 192, 0.7)',
        data: initialValue
    }]
};

// 차트 그리기(초기)
myChart1 = new Chart(ctx1, {
    type: 'bar',
    data: initialData,
    options: {
        scales: {
            x: {
                stacked: false
            },
            y: {
                stacked: false
            }
        }
    }
});
myChart2 = new Chart(ctx2, {
    type: 'bar',
    data: initialData,
    options: {
        scales: {
            x: {
                stacked: false
            },
            y: {
                stacked: false
            }
        }
    }
});


//지도 생성
const container = document.getElementById('map');
const options = {
    center: new kakao.maps.LatLng(36, 127.5),
    level: 13,
    disableDoubleClickZoom: true
};
const map = new kakao.maps.Map(container, options);

// const customOverlay = new kakao.maps.CustomOverlay({});
const infowindow = new kakao.maps.InfoWindow({ removable: true });

map.setZoomable(false); // 확대 막기
map.setCursor('default');

let data = geojson.features; //geojson에서 필요한 값(features)만 추출
var coordinates = []; //좌표 저장할 배열
var name = ''; // 지역 이름


// data에서 좌표 끌고와 polygon&이벤트 만들기
data.forEach((val) => {
    coordinates = val.geometry.coordinates;
    name = val.properties.SIG_KOR_NM;
    displayArea(coordinates, name);
});

// polygon 만들고 마우스 이벤트 주는 메소드
function displayArea(coordinates, name) {
    let path = [];
    let points = [];

    coordinates[0].forEach((coordinate) => {
        path.push(new kakao.maps.LatLng(coordinate[1], coordinate[0]));
        var point = new Object();
        point.x = coordinate[1];
        point.y = coordinate[0];
        points.push(point);
    });
    //polygon 생성
    let polygon = new kakao.maps.Polygon({
        map: map,
        path: path, // 그려질 다각형의 좌표 배열입니다
        strokeWeight: 2, // 선의 두께입니다
        strokeColor: '#004c80', // 선의 색깔입니다
        strokeOpacity: 0.5, // 선의 불투명도 입니다 1에서 0 사이의 값이며 0에 가까울수록 투명합니다
        strokeStyle: 'solid', // 선의 스타일입니다
        fillColor: '#ffffff', // 채우기 색깔입니다
        fillOpacity: 0.8, // 채우기 불투명도 입니다
    });

    //폴리곤 중심좌표 구하는 메소드(centroid 알고리즘)
    function centerMap(points) {
        var i, j, len, p1, p2, f, area, x, y;
        area = x = y = 0;

        for (i = 0, len = points.length, j = len - 1; i < len; j = i++) {
            p1 = points[i];
            p2 = points[j];

            f = p1.y * p2.x - p2.y * p1.x;
            x += (p1.x + p2.x) * f;
            y += (p1.y + p2.y) * f;
            area += f * 3;
        }
        return new kakao.maps.LatLng(x / area, y / area);
    }

    //오버레이 생성 메소드
    function overlaySet(name, points) {
        var content = '<div class="area" style="font-weight:bold; font-size:10px; color:black;">' + name + '</div>';

        // 커스텀 오버레이가 표시될 위치입니다 
        var position = centerMap(points);

        // 커스텀 오버레이를 생성합니다
        var customOverlay = new kakao.maps.CustomOverlay({
            position: position,
            content: content,
            xAnchor: 0.3,
            yAnchor: 0.91
        });

        // 커스텀 오버레이를 지도에 표시합니다
        customOverlay.setMap(map);
        var overlay = document.querySelector(".area");
        kakao.maps.event
    }
    overlaySet(name, points);  // 오버레이 생성

    // 다각형에 mouseover하면 폴리곤의 채움색을 변경합니다
    kakao.maps.event.addListener(polygon, 'mouseover', function (mouseEvent) {
        polygon.setOptions({ fillColor: '#09f' });
    });

    // 다각형에 mouseout 이벤트를 등록하고 이벤트가 발생하면 폴리곤의 채움색을 원래색으로 변경합니다
    kakao.maps.event.addListener(polygon, 'mouseout', function () {
        polygon.setOptions({ fillColor: '#ffffff' });
    });

    //다각형 클릭 이벤트
    kakao.maps.event.addListener(polygon, 'click', function () {
        var regionTitle = document.querySelector("#regionTitle");
        regionTitle.innerHTML = name;
        var contentRegion = document.querySelector("#contentRegion");
        contentRegion.innerHTML = name;

        //응급실 차트에 비교 데이터 추가
        targetRegion = name;
        if (myChart1.data.datasets.length > 1) {
            myChart1.data.datasets.pop();
        }

        addtionalValue = [];

        erData.forEach((val) => {
            if (val.region == targetRegion) {
                addtionalValue.push(val.within60);
                addtionalValue.push(val.inside);
                addtionalValue.push(val.within30);
            }
        })

        // 새로운 데이터셋 추가
        myChart1.data.datasets.push({
            label: targetRegion,
            backgroundColor: 'rgba(255, 99, 132, 0.7)',
            data: addtionalValue
        });

        myChart1.update();
        myChart2.update();

    });
};

// 응급실 지표 팝업창 띄우기
var popOpen = document.querySelector("#popOpen");
popOpen.addEventListener("click", function () {
    var pop = document.querySelector("#popWrap");
    pop.classList.remove('hide');
})

var popClose = document.querySelector("#popClose");
popClose.addEventListener("click", function () {
    var pop = document.querySelector("#popWrap");
    pop.classList.add('hide');
})

//과거 날짜 검색 제한
var now_utc = Date.now() // 지금 날짜를 밀리초로, getTimezoneOffset()은 현재 시간과의 차이를 분 단위로 반환
var timeOff = new Date().getTimezoneOffset() * 60000; // 분단위를 밀리초로 변환
var year = new Date(now_utc - timeOff).toISOString().split("-")[0]; //'yyyy-mm-ddT18:09:38.134Z'에서 년 추출
var month = new Date(now_utc - timeOff).toISOString().split("-")[1]; //월 추출
var thisMonth = year + "-" + month; // 현재시점의 yyyy-mm 
document.getElementById("month").setAttribute("min", thisMonth);
document.getElementById("month").setAttribute("value", thisMonth);

//지도 반응형
var ro = new ResizeObserver(entries => {
    for (let entry of entries) {
        map.relayout();
        centerReset();
    }
});

ro.observe(mapWrap);

function centerReset() {
    var moveLatLon = new kakao.maps.LatLng(36, 127.5);
    map.setCenter(moveLatLon);
}
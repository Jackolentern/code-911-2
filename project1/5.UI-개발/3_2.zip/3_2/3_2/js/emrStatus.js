
var rightSection = document.getElementById("rightSection");
var seoulMap = document.getElementById("seoulMap");
var gu;
var address;
// 페이지이동
function fnMove(seq) {
  var offset = $("#page" + seq).offset();
  $('html, body').animate({ scrollTop: offset.top - 110 }, 100);
}

// currentLocationBorder 함수 정의
function currentLocationBorder(){
    // rightSection의 자식 노드 전체를 삭제
    rightSection.replaceChildren();
  
    // 좌측 이전 버튼 생성
    var leftButton = document.createElement("button");
    leftButton.id = 'previousButton';
    leftButton.className = "bi bi-chevron-double-left text-secondary";
    leftButton.addEventListener('click', previousGu);
  
    // 우측 다음 버튼 생성
    var rightButton = document.createElement("button");
    rightButton.id = 'nextButton';
    rightButton.className = "bi bi-chevron-double-right text-secondary";
    rightButton.addEventListener('click', nextGu);
  
    // "현재위치" 텍스트를 담을 div 요소 생성
    var text1 = document.createElement("div");
    text1.textContent = ("현재위치");
    text1.style.fontSize = "1.2em ";
  
    // 현재 위치 정보를 담을 div 요소 생성
    let gubox = document.createElement("div");
    gubox.id = 'present';
    gubox.style = "height: 25px; animation: fadeInUp 1s;"
  
    // 전체 현재 위치 UI를 감싸는 div 요소 생성
    var currentLocation = document.createElement("div");
    currentLocation.style="background: rgb(255, 255, 255);"
    currentLocation.id = 'currentLocation';
    
    // 현재 위치 UI 조립
    currentLocation.appendChild(text1);
    currentLocation.appendChild(gubox);
  
    // 전체 현재 위치 UI를 감싸는 div 요소를 병원 UI로 추가
    var hospital = document.createElement("div");
    hospital.id = 'hospital'
    hospital.appendChild(leftButton);
    hospital.appendChild(currentLocation);
    hospital.appendChild(rightButton);
  
    // 병원 UI를 rightSection에 추가
    rightSection.appendChild(hospital);
  }
  
// inputData 함수 정의
function inputData(data){
    // 주어진 데이터의 길이만큼 반복문 실행
    for(var i = 0; i<data.length; i++){
      // 홀수 번째 또는 첫 번째 항목일 때 새로운 병원을 담을 div 요소 생성
      if(i%2===0 || i===0){
        var hospitalBody = document.createElement("div");
        hospitalBody.style = "display: flex; justify-content: space-around; margin-top: 50px;  position: relative; animation: fadeInUp 1s;";
      }
  
      // 각 병원의 정보를 담을 div 요소 생성
      var row = document.createElement("div");
      row.style = "width: 200px; text-align: center; box-shadow: 5px 5px 3px #666; border-radius: 20px; border: 2px solid black; margin-bottom: 20px;";
      row.className = "align-botoom";
  
      // 병원 이름을 나타낼 p 요소 생성
      var nameCell = document.createElement("p");
      nameCell.textContent = data[i].name;
      nameCell.style = "border-bottom: 1px solid black; height: 60px; margin: 0; font-weight: bold; font-size: 1.2em; padding: auto; display: flex; align-items: center; justify-content: center;";
      nameCell.className = "text-primary emrName";
  
      // 전화번호를 나타낼 p 요소 생성
      var telnumCell = document.createElement("p");
      telnumCell.innerHTML = '<span class="bi bi-telephone-fill">' + " " + data[i].telnum + "</span>";
      telnumCell.style = "height: 25px; line-height: 25px; margin: 0;";
      telnumCell.className = "text-secondary";
  
      // 주소 및 자세히 버튼을 나타낼 p 요소 생성
      var addressCell = document.createElement("p");
      addressCell.innerHTML = '<span class="bi bi-map-fill">' + " " +data[i].address + "</span>" + "<br>" + '  <button id="show" class="btn btn-primary">자세히</button>';
      addressCell.style = "border-top: 1px solid black;";
      addressCell.className = "text-secondary emrAddress";
  
      // 각 정보를 병원 정보 div에 추가
      row.appendChild(nameCell);
      row.appendChild(telnumCell);
      row.appendChild(addressCell);
      hospitalBody.appendChild(row);
  
      // 홀수 번째 항목이거나 첫 번째 항목일 때, 생성된 병원 정보 div를 웹 페이지에 추가
      if(i-1===0 || (i-1)%2===0){
        rightSection.appendChild(hospitalBody);
      } else if(row!=null){ //남은 데이터가 없을시 생성된 병원 정보 div를 웹 페이지에 추가
        rightSection.appendChild(hospitalBody);
      }
    }
  }
  
// 행정구역 클릭 함수 정의
function clickDobong(){
  seoulMap.src = "img/seoulMap/Dobong.PNG"
  currentLocationBorder();
  gu = "도봉";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "의료법인한전의료재단한일병원", telnum: "02-901-3114", address: "서울특별시 도봉구 우이천로 308, 한일병원 (쌍문동)"}
  ]
  inputData(data);
};
function clickDongdaemun(){
  seoulMap.src = "img/seoulMap/Dongdaemun.PNG"
  currentLocationBorder();
  gu = "동대문";
  document.getElementById("present").innerText = gu;
};
function clickDongjak(){
  seoulMap.src = "img/seoulMap/Dongjak.PNG"
  currentLocationBorder();
  gu = "동작";
  document.getElementById("present").innerText = gu;
};
function clickEunpyeong(){
  seoulMap.src = "img/seoulMap/Eunpyeong.PNG"
  currentLocationBorder();
  gu = "은평";
  document.getElementById("present").innerText = gu;
};
function clickGangbuk(){
  seoulMap.src = "img/seoulMap/Gangbuk.PNG"
  currentLocationBorder();
  gu = "강북";
  document.getElementById("present").innerText = gu;
  let nullText = document.createElement("div");
  nullText.innerHTML = "강북구에는 응급실이 없습니다.<br>주변 지역을 클릭하면<br> 다른 응급실을 제공해드립니다.";
  nullText.className = "text-secondary text-center";
  nullText.style="font-size: 2em; margin-top: 50px; animation: fadeInUp 1s";
  rightSection.appendChild(nullText);
};
function clickGangdong(){
  seoulMap.src = "img/seoulMap/Gangdong.PNG"
  currentLocationBorder();
  gu = "강동";
  document.getElementById("present").innerText = gu;
};
function clickGangnam(){
  seoulMap.src = "img/seoulMap/Gangnam.PNG"
  currentLocationBorder();
  gu = "강남";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "	연세대학교의과대학강남세브란스병원", telnum: "02-2019-3114", address: "서울특별시 강남구 언주로 211, 강남세브란스병원 (도곡동)"},
    { name: "삼성서울병원", telnum: "02-3410-2114", address: "서울특별시 강남구 일원로 81 (일원동, 삼성의료원)"}
  ]
  inputData(data);
};
function clickGangseo(){
  seoulMap.src = "img/seoulMap/Gangseo.PNG"
  currentLocationBorder();
  gu = "강서";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "이화여자대학교의과대학부속서울병원", telnum: "02-6986-5119", address: "서울특별시 강서구 공항대로 260, 이화의대부속서울병원 (마곡동)"},
    { name: "부민병원", telnum: "02-2620-0119", address: "서울특별시 강서구 공항대로 389, 부민병원 (등촌동)"}
  ]
  inputData(data);
};
function clickGeumcheon(){
  seoulMap.src = "img/seoulMap/Geumcheon.PNG"
  currentLocationBorder();
  gu = "금천";
  document.getElementById("present").innerText = gu;
};
function clickGuro(){
  seoulMap.src = "img/seoulMap/Guro.PNG"
  currentLocationBorder();
  gu = "구로";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "구로성심병원", telnum: "02-2067-1515", address: "서울특별시 구로구 경인로 427, 구로성심병원 (고척동)"},
    { name: "고려대학교의과대학부속구로병원", telnum: "02-2626-1550", address: "서울특별시 구로구 구로동로 148, 고려대부속구로병원 (구로동)"}
  ]
  inputData(data);
};
function clickGwanak(){
  seoulMap.src = "img/seoulMap/Gwanak.PNG"
  currentLocationBorder();
  gu = "관악";
  document.getElementById("present").innerText = gu;
};
function clickGwangjin(){
  seoulMap.src = "img/seoulMap/Gwangjin.PNG"
  currentLocationBorder();
  gu = "광진";
  document.getElementById("present").innerText = gu;
};
function clickJongno(){
  seoulMap.src = "img/seoulMap/Jongno.PNG"
  currentLocationBorder();
  gu = "종로";
  document.getElementById("present").innerText = gu;
};
function clickJung(){
  seoulMap.src = "img/seoulMap/Jung.PNG"
  currentLocationBorder();
  gu = "중구";
  document.getElementById("present").innerText = gu;
};
function clickJungnang(){
  seoulMap.src = "img/seoulMap/Jungnang.PNG"
  currentLocationBorder();
  gu = "중랑";
  document.getElementById("present").innerText = gu;
};
function clickMapo(){
  seoulMap.src = "img/seoulMap/Mapo.PNG"
  currentLocationBorder();
  gu = "마포";
  document.getElementById("present").innerText = gu;
  let nullText = document.createElement("div");
  nullText.innerHTML = "마포구에는 응급실이 없습니다.<br>주변 지역을 클릭하면<br> 다른 응급실을 제공해드립니다.";
  nullText.className = "text-secondary text-center";
  nullText.style="font-size: 2em; margin-top: 50px; animation: fadeInUp 1s";
  rightSection.appendChild(nullText);
};
function clickNowon(){
  seoulMap.src = "img/seoulMap/Nowon.PNG"
  currentLocationBorder();
  gu = "노원";
  document.getElementById("present").innerText = gu;
};
function clickSeocho(){
  seoulMap.src = "img/seoulMap/Seocho.PNG"
  currentLocationBorder();
  gu = "서초";
  document.getElementById("present").innerText = gu;
};
function clickSeodaemun(){
  seoulMap.src = "img/seoulMap/Seodaemun.PNG"
  currentLocationBorder();
  gu = "서대문";
  document.getElementById("present").innerText = gu;
  var data =[
    {name:"연세대학교의과대학세브란스병원", telnum: "02-2228-0114", address: "서울특별시 서대문구 연세로 50-1 (신촌동)"},
    {name:"의료법인동신의료재단 동신병원", telnum: "02-396-9161", address: "서울특별시 서대문구 연희로 272, 동신병원 본관동 (홍은동)"}
  ]
  inputData(data);
};
function clickSeongbuk(){
  seoulMap.src = "img/seoulMap/Seongbuk.PNG"
  currentLocationBorder();
  gu = "성북";
  document.getElementById("present").innerText = gu;
};
function clickSeongdong(){
  seoulMap.src = "img/seoulMap/Seongdong.PNG"
  currentLocationBorder();
  gu = "성동";
  document.getElementById("present").innerText = gu;
};
function clickSongpa(){
  seoulMap.src = "img/seoulMap/Songpa.PNG"
  currentLocationBorder();
  gu = "송파";
  document.getElementById("present").innerText = gu;
};
function clickYangcheon(){
  seoulMap.src = "img/seoulMap/Yangcheon.PNG"
  currentLocationBorder();
  gu = "양천";
  document.getElementById("present").innerText = gu;
  var data = [
    { name: "홍익병원", telnum: "02-2693-5555 ", address: "서울특별시 양천구 목동로 225, 홍익병원본관 (신정동)"},
    { name: "서울특별시서남병원", telnum: "1566-6688", address: "서울특별시 양천구 신정이펜1로 20 (신정동)"},
    { name: "이화여자대학교의과대학부속목동병원", telnum: "02-2650-5911", address: "	서울특별시 양천구 안양천로 1071 (목동)"}
  ]
  inputData(data);
};
function clickYeongdeungpo(){
  seoulMap.src = "img/seoulMap/Yeongdeungpo.PNG"
  currentLocationBorder();
  gu = "영등포";
  document.getElementById("present").innerText = gu;
};
function clickYongsan(){
  seoulMap.src = "img/seoulMap/Yongsan.PNG"
  currentLocationBorder();
  gu = "용산";
  document.getElementById("present").innerText = gu;
};
// 눌러서 다음구보기
function nextGu(){
  let thisGu = document.getElementById("present").innerText;
  let arr = [clickGangnam, clickGangdong, clickGangbuk, clickGangseo, clickGwanak, clickGwangjin, clickGuro, clickGeumcheon, clickNowon, clickDobong, clickDongdaemun, clickDongjak, clickMapo, clickSeodaemun, clickSeocho, clickSeongdong, clickSeongbuk, clickSongpa, clickYangcheon, clickYeongdeungpo, clickYongsan, clickEunpyeong, clickJongno, clickJung, clickJungnang];
  let guu = ["강남", "강동", "강북", "강서", "관악", "광진", "구로", "금천", "노원", "도봉", "동대문", "동작", "마포", "서대문", "서초", "성동", "성북", "송파", "양천", "영등포", "용산", "은평", "종로", "중구", "중랑"];
  for(let i=0; i<arr.length; i++){
    if(thisGu===null||thisGu===""||thisGu==="중랑"){
      arr[0](); // 첫 번째 함수 호출
      break;
    } else if(thisGu===guu[i]){
      arr[i+1](); // 현재 위치의 다음 함수 호출
      break;
    } 
  }
}
// 눌러서 이전구보기
function previousGu(){
  let thisGu = document.getElementById("present").innerText;
  let arr = [clickGangnam, clickGangdong, clickGangbuk, clickGangseo, clickGwanak, clickGwangjin, clickGuro, clickGeumcheon, clickNowon, clickDobong, clickDongdaemun, clickDongjak, clickMapo, clickSeodaemun, clickSeocho, clickSeongdong, clickSeongbuk, clickSongpa, clickYangcheon, clickYeongdeungpo, clickYongsan, clickEunpyeong, clickJongno, clickJung, clickJungnang];
  let guu = ["강남", "강동", "강북", "강서", "관악", "광진", "구로", "금천", "노원", "도봉", "동대문", "동작", "마포", "서대문", "서초", "성동", "성북", "송파", "양천", "영등포", "용산", "은평", "종로", "중구", "중랑"];
  for(let i=arr.length-1; i<arr.length; i--){
    if(thisGu===null||thisGu===""||thisGu==="강남"){
      arr[24](); // 마지막 함수 호출
      break;
    } else if(thisGu===guu[i]){
      arr[i-1](); // 현재 위치의 이전 함수 호출
      break;
    } 
  }
}
//서울 이미지맵 반응형 웹
$(document).ready(function() {
  $('img[usemap]').rwdImageMaps();
});

// 각 응급실 이름을 통해 검색 후 좌표 이동
function show(content) {
  for(let i=0; i<positions.length; i++){
    if(positions[i].title === content){
      // 이동할 위도 경도 위치를 생성합니다 
      var moveLatLon = positions[i].latlng;
      //페이지를 지도로 이동시킵니다
      fnMove(1)
      // 지도 중심을 이동 시킵니다
      map.setCenter(moveLatLon);
    }
  } 
}

// 버튼 클릭 이벤트 등록
document.addEventListener('click', function(event) {
  if (event.target.id === 'show') {
    // 부모 노드에서 주소를 가져옴
    var parent = event.target.closest(".align-botoom");
    var emrName = parent.querySelector(".emrName").textContent.trim();
    var emrAddress = parent.querySelector(".emrAddress").textContent.slice(0, -3);
    show(emrName);
  }
});



var mapContainer = document.getElementById('map'), // 지도를 표시할 div  
                mapOption = { 
                    center: new kakao.maps.LatLng(37.5642135, 127.0016985), // 지도의 중심좌표
                    level: 6 // 지도의 확대 레벨

                };
            
            var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다
            // 지도 크기 조절
            var minZoomLevel = 4;
            var maxZoomLevel = 8;

            // setMinLevel() 메서드를 사용하여 최소 지도 확대 수준 설정
            map.setMinLevel(minZoomLevel);
            map.setMaxLevel(maxZoomLevel);

            

            // 마커를 표시할 위치와 title 객체 배열입니다 
            var positions = [
                {
                    //1
                    title: '가톨릭대학교여의도성모병원', 
                    latlng: new kakao.maps.LatLng(37.51827234, 126.9367313)
                },
                {
                    //2
                    title: '가톨릭대학교은평성모병원', 
                    latlng: new kakao.maps.LatLng(37.63360841, 126.9161505)
                },
                {
                    //3
                    title: '강동경희대학교의대병원',
                    latlng: new kakao.maps.LatLng(37.55204593, 127.1570848)
                },

                {
                    //4
                    title: '강북삼성병원',
                    latlng: new kakao.maps.LatLng(37.56849763, 126.9679381)
                },
                {
                    //5
                    title: '건국대학교병원',
                    latlng: new kakao.maps.LatLng(37.54084479, 127.0721229)
                },
                {
                    //6
                    title: '경찰병원',
                    latlng: new kakao.maps.LatLng(37.49641321, 127.1234879)
                },
                {
                    //7
                    title: '경희대학교병원',
                    latlng: new kakao.maps.LatLng(37.59387655, 127.0518322)
                },
                {
                    //8
                    title: '고려대학교의과대학부속구로병원',
                    latlng: new kakao.maps.LatLng(37.49211115, 126.8847449)
                },
                {
                    //9
                    title: '구로성심병원',
                    latlng: new kakao.maps.LatLng(37.49964579, 126.8663604)
                },
                {
                    //10
                    title: '국립중앙의료원',
                    latlng: new kakao.maps.LatLng(37.56733956, 127.0057954)
                },
                {
                    //11
                    title: '노원을지대학교병원',
                    latlng: new kakao.maps.LatLng(37.63644293, 127.0700028)
                },
                {
                    //12
                    title: '녹색병원',
                    latlng: new kakao.maps.LatLng(37.58362084, 127.0860555)
                },
                {
                    //13
                    title: '대림성모병원',
                    latlng: new kakao.maps.LatLng(37.49068925, 126.9071695)
                },
                {
                    //14
                    title: '명지성모병원',
                    latlng: new kakao.maps.LatLng(37.49385071, 126.8992545)
                },
                {
                    //15
                    title: '부민병원',
                    latlng: new kakao.maps.LatLng(37.55694089, 126.8509495)
                },
                {
                    //16
                    title: '삼성서울병원',
                    latlng: new kakao.maps.LatLng(37.48851613, 127.0866825)
                },
                {
                    //17
                    title: '삼육서울병원',
                    latlng: new kakao.maps.LatLng(37.587992, 127.0653288)
                },
                {
                    //18
                    title: '서울대학교병원',
                    latlng: new kakao.maps.LatLng(37.57966609, 126.9989631)
                },
                {
                    //19
                    title: '서울성심병원',
                    latlng: new kakao.maps.LatLng(37.58419129, 127.0498381)
                },
                {
                    //20
                    title: '서울적십자병원',
                    latlng: new kakao.maps.LatLng(37.56715536, 126.9669986)
                },
                {
                    //21
                    title: '서울특별시동부병원',
                    latlng: new kakao.maps.LatLng(37.57539886, 127.0314026)
                },
                {
                    //22
                    title: '서울특별시보라매병원',
                    latlng: new kakao.maps.LatLng(37.4937184, 126.9240488)
                },
                {
                    //23
                    title: '서울특별시서남병원',
                    latlng: new kakao.maps.LatLng(37.51201936, 126.8331299)
                },
                {
                    //24
                    title: '서울특별시서울의료원',
                    latlng: new kakao.maps.LatLng(37.61286932, 127.0980911)
                },
                {
                    //25
                    title: '성심의료재단강동성심병원',
                    latlng: new kakao.maps.LatLng(37.53598408, 127.1352635)
                },
                {
                    //26
                    title: '성애의료재단성애병원',
                    latlng: new kakao.maps.LatLng(37.51205045, 126.9223673)
                },
                {
                    //27
                    title: '세란병원',
                    latlng: new kakao.maps.LatLng(37.57534017, 126.9577072)
                },
                {
                    //28
                    title: '순천향대학교 부속 서울병원',
                    latlng: new kakao.maps.LatLng(37.53384172, 127.004418)
                },
                {
                    //29
                    title: '연세대학교의과대학강남세브란스병원',
                    latlng: new kakao.maps.LatLng(37.49280698, 127.0463125)
                },
                {
                    //30
                    title: '연세대학교의과대학세브란스병원',
                    latlng: new kakao.maps.LatLng(37.56211711, 126.9408277)
                },
                {
                    //31
                    title: '의료법인동신의료재단 동신병원',
                    latlng: new kakao.maps.LatLng(37.58110428, 126.9365831)
                },
                {
                    //32
                    title: '의료법인서울효천의료재단 에이치플러스양지병원',
                    latlng: new kakao.maps.LatLng(37.48427507, 126.9325392)
                },
                {
                    //33
                    title: '의료법인청구성심병원',
                    latlng: new kakao.maps.LatLng(37.62079154, 126.919554)
                },
                {
                    //34
                    title: '의료법인풍산의료재단동부제일병원',
                    latlng: new kakao.maps.LatLng(37.60067565, 127.1090292)
                },
                {
                    //35
                    title: '의료법인한전의료재단한일병원',
                    latlng: new kakao.maps.LatLng(37.6461157, 127.0290242)
                },
                {
                    //36
                    title: '이화여자대학교의과대학부속목동병원',
                    latlng: new kakao.maps.LatLng(37.53654283, 126.886216)
                },
                {
                    //37
                    title: '이화여자대학교의과대학부속서울병원',
                    latlng: new kakao.maps.LatLng(37.55726115, 126.8362659)
                },
                {
                    //38
                    title: '인제대학교상계백병원',
                    latlng: new kakao.maps.LatLng(37.64858127, 127.0631162)
                },
                {
                    //39
                    title: '재단법인아산사회복지재단 서울아산병원',
                    latlng: new kakao.maps.LatLng(37.52656397, 127.1082383)
                },
                {
                    //40
                    title: '중앙대학교병원',
                    latlng: new kakao.maps.LatLng(37.50707428, 126.9607938)
                },
                {
                    //41
                    title: '학교법인 고려중앙학원 고려대학교의과대학부속병원(안암병원)',
                    latlng: new kakao.maps.LatLng(37.58715608, 127.0264709)
                },
                {
                    //42
                    title: '학교법인가톨릭학원가톨릭대학교서울성모병원',
                    latlng: new kakao.maps.LatLng(37.5018008, 127.0047273)
                },
                {
                    //43
                    title: '한국보훈복지의료공단 중앙보훈병원',
                    latlng: new kakao.maps.LatLng(37.5282209, 127.1467189)
                },
                {
                    //44
                    title: '한국원자력의학원원자력병원',
                    latlng: new kakao.maps.LatLng(37.62881598, 127.0826932)
                },
                {
                    //45
                    title: '한림대학교강남성심병원',
                    latlng: new kakao.maps.LatLng(37.49324929, 126.9086725)
                },
                {
                    //46
                    title: '한양대학교병원',
                    latlng: new kakao.maps.LatLng(37.55994453, 127.0448828)
                },
                {
                    //47
                    title: '혜민병원',
                    latlng: new kakao.maps.LatLng(37.53531566, 127.0836013)
                },
                {
                    //48
                    title: '홍익병원',
                    latlng: new kakao.maps.LatLng(37.52844141, 126.863664)
                },
                {
                    //49
                    title: '희명병원',
                    latlng: new kakao.maps.LatLng(37.45567063, 126.9005625)
                }
            ];
            
            //마커 이미지 설정
            var imageSrc = "img/emergencyMarker.png";
            var imageSize = new kakao.maps.Size(24, 35);
            var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

            // 지역별 마커 찍기
            // 1.가톨릭대학교여의도성모병원
            var hospital0 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[0].latlng, // 마커를 표시할 위치
                title: positions[0].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 2.가톨릭대학교은평성모병원
            var hospital1 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[1].latlng, // 마커를 표시할 위치
                title: positions[1].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 3.강동경희대학교의대병원
            var hospital2 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[2].latlng, // 마커를 표시할 위치
                title: positions[2].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 4.강북삼성병원
            var hospital3 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[3].latlng, // 마커를 표시할 위치
                title: positions[3].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });

            // 5.건국대학교병원
            var hospital4 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[4].latlng, // 마커를 표시할 위치
                title: positions[4].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 6.경찰병원
            var hospital5 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[5].latlng, // 마커를 표시할 위치
                title: positions[5].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 7.경희대학교병원
            var hospital6 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[6].latlng, // 마커를 표시할 위치
                title: positions[6].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 8.고려대학교의과대학부속구로병원
            var hospital7 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[7].latlng, // 마커를 표시할 위치
                title: positions[7].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 9.구로성심병원
            var hospital8 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[8].latlng, // 마커를 표시할 위치
                title: positions[8].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 10.국립중앙의료원
            var hospital9 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[9].latlng, // 마커를 표시할 위치
                title: positions[9].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 11.노원을지대학교병원
            var hospital10 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[10].latlng, // 마커를 표시할 위치
                title: positions[10].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 12.녹색병원
            var hospital11 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[11].latlng, // 마커를 표시할 위치
                title: positions[11].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 13.대림성모병원
            var hospital12 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[12].latlng, // 마커를 표시할 위치
                title: positions[12].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 14.명지성모병원
            var hospital13 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[13].latlng, // 마커를 표시할 위치
                title: positions[13].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 15.부민병원
            var hospital14 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[14].latlng, // 마커를 표시할 위치
                title: positions[14].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 16.삼성서울병원
            var hospital15 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[15].latlng, // 마커를 표시할 위치
                title: positions[15].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 17.삼육서울병원
            var hospita16 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[16].latlng, // 마커를 표시할 위치
                title: positions[16].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 18.서울대학교병원
            var hospital17 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[17].latlng, // 마커를 표시할 위치
                title: positions[17].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 19.서울성심병원
            var hospital18 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[18].latlng, // 마커를 표시할 위치
                title: positions[18].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 20.서울적십자병원
            var hospital19 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[19].latlng, // 마커를 표시할 위치
                title: positions[19].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 21.서울특별시동부병원
            var hospita20 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[20].latlng, // 마커를 표시할 위치
                title: positions[20].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 22.서울특별시보라매병원
            var hospital21 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[21].latlng, // 마커를 표시할 위치
                title: positions[21].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 23.서울특별시서남병원
            var hospital22 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[22].latlng, // 마커를 표시할 위치
                title: positions[22].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 24.서울특별시서울의료원
            var hospital23 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[23].latlng, // 마커를 표시할 위치
                title: positions[23].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 25.성심의료재단강동성심병원
            var hospital24 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[24].latlng, // 마커를 표시할 위치
                title: positions[24].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 26.성애의료재단성애병원
            var hospital25 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[25].latlng, // 마커를 표시할 위치
                title: positions[25].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 27.세란병원
            var hospital26 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[26].latlng, // 마커를 표시할 위치
                title: positions[26].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 28.순천향대학교 부속 서울병원
            var hospital27 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[27].latlng, // 마커를 표시할 위치
                title: positions[27].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 29.연세대학교의과대학강남세브란스병원
            var hospital28 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[28].latlng, // 마커를 표시할 위치
                title: positions[28].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 30.연세대학교의과대학세브란스병원
            var hospital29 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[29].latlng, // 마커를 표시할 위치
                title: positions[29].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 31.의료법인동신의료재단 동신병원
            var hospital30 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[30].latlng, // 마커를 표시할 위치
                title: positions[30].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 32.의료법인서울효천의료재단 에이치플러스양지병원
            var hospital31 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[31].latlng, // 마커를 표시할 위치
                title: positions[31].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 33.의료법인청구성심병원
            var hospital32 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[32].latlng, // 마커를 표시할 위치
                title: positions[32].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 34.의료법인풍산의료재단동부제일병원
            var hospital33 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[33].latlng, // 마커를 표시할 위치
                title: positions[33].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 35.의료법인한전의료재단한일병원
            var hospital34 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[34].latlng, // 마커를 표시할 위치
                title: positions[34].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 36.이화여자대학교의과대학부속목동병원
            var hospital35 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[35].latlng, // 마커를 표시할 위치
                title: positions[35].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 37.이화여자대학교의과대학부속서울병원
            var hospital36 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[36].latlng, // 마커를 표시할 위치
                title: positions[36].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 38.인제대학교상계백병원
            var hospital37 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[37].latlng, // 마커를 표시할 위치
                title: positions[37].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 39.재단법인아산사회복지재단 서울아산병원
            var hospital38 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[38].latlng, // 마커를 표시할 위치
                title: positions[38].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 40.중앙대학교병원
            var hospital39 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[39].latlng, // 마커를 표시할 위치
                title: positions[39].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 41.학교법인 고려중앙학원 고려대학교의과대학부속병원(안암병원)
            var hospital40 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[40].latlng, // 마커를 표시할 위치
                title: positions[40].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 42.학교법인가톨릭학원가톨릭대학교서울성모병원
            var hospital41 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[41].latlng, // 마커를 표시할 위치
                title: positions[41].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 43.한국보훈복지의료공단 중앙보훈병원
            var hospital42 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[42].latlng, // 마커를 표시할 위치
                title: positions[42].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 44.한국원자력의학원원자력병원
            var hospital43 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[43].latlng, // 마커를 표시할 위치
                title: positions[43].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 45.한림대학교강남성심병원
            var hospital44 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[44].latlng, // 마커를 표시할 위치
                title: positions[44].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 46.한양대학교병원
            var hospital45 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[45].latlng, // 마커를 표시할 위치
                title: positions[45].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 47.혜민병원
            var hospital46 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[46].latlng, // 마커를 표시할 위치
                title: positions[46].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 48.홍익병원
            var hospital47 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[47].latlng, // 마커를 표시할 위치
                title: positions[47].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });
            // 49.희명병원
            var hospital48 = new kakao.maps.Marker({
                map: map, // 마커를 표시할 지도
                position: positions[48].latlng, // 마커를 표시할 위치
                title: positions[48].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
                image: markerImage, // 마커 이미지 
                clickable: true
            });     
            // 지도에 마커와 인포윈도우를 표시하는 함수입니다
            function displayMarker(locPosition, message) {
            
                // 마커를 생성합니다
                var marker = new kakao.maps.Marker({  
                    map: map, 
                    position: locPosition
                }); 
                
                var iwContent = message, // 인포윈도우에 표시할 내용
                    iwRemoveable = true;
            
                // 인포윈도우를 생성합니다
                var infowindow = new kakao.maps.InfoWindow({
                    content : iwContent,
                    removable : iwRemoveable
                });
                
                // 인포윈도우를 마커위에 표시합니다 
                infowindow.open(map, marker);
                
                // 지도 중심좌표를 접속위치로 변경합니다
                map.setCenter(locPosition);      
            }   

            function findMyLocation() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function (position) {
                        var lat = position.coords.latitude,
                            lon = position.coords.longitude;
    
                        var locPosition = new kakao.maps.LatLng(lat, lon),
                            message = '<div style="padding:5px;">현재 위치</div>';
    
                        displayMarker(locPosition, message);
                    });
                } else {
                    var locPosition = new kakao.maps.LatLng(33.450701, 126.570667),
                        message = 'geolocation을 사용할수 없어요..';
    
                    displayMarker(locPosition, message);
                }
            }

            findMyLocation();

            

    // 마커에 클릭 이벤트 등록
    kakao.maps.event.addListener(hospital3, 'click', function() {
        changeBoard(0);
        drawChart(0);
    }); // 강북삼성병원
    kakao.maps.event.addListener(hospital19, 'click', function() {
        changeBoard(1);
        drawChart(1);
    }); // 서울적십자병원
    
    kakao.maps.event.addListener(hospital26, 'click', function() {
        changeBoard(2);
        drawChart(2);
    }); // 세란병원
    
    kakao.maps.event.addListener(hospital29, 'click', function() {
        changeBoard(3);
        drawChart(3);
    }); // 연세대학교의과대학세브란스병원

    kakao.maps.event.addListener(hospital30, 'click', function() {
        changeBoard(4);
        drawChart(4);
    }); // 의료법인동신의료재단 동신병원 

    // 내 위치 버튼을 클릭하면 화면에 내 위치 표시
    var myLocationButton = document.querySelector("#myLocation");

        myLocationButton.addEventListener('click', findMyLocation);
        
    
    // 응급실 데이터 배열
    var hospitalData = [
        {name: "강북삼성병원", hvgc: 95, hvoc: 0, hperyn: 13, hvec: 13,
         emReceive1: "", emReceive2: "", emReceive3: ""},

        {name: "서울적십자병원", hvgc: 82, hvoc: 5, hperyn: 10, hvec: 4,
         emReceive1: "", emReceive2: "", emReceive3: ""},
        
        {name: "세란병원", hvgc: 35, hvoc: 2, hperyn: 10, hvec: 9,
        emReceive1: "응급", emReceive2: "응급실", emReceive3: "ct 촬영 불가."},

        {name: "연세대학교의과대학세브란스병원", hvgc: 38, hvoc: 2, hperyn: 41, hvec: 22,
        emReceive1: "응급", emReceive2: "응급실", emReceive3: "격리진료구역병상 성인/소아 구분 신고 체계 미비로 실제 정보와 다를 수 있음."},

        {name: "의료법인동신의료재단 동신병원", hvgc: 100, hvoc: 0, hperyn: 41, hvec: -36,
        emReceive1: "", emReceive2: "", emReceive3: ""}
    ]

    function changeBoard(index) {
        var hospitalName = document.querySelector("#hospital-name");
        var confusedLevel = document.querySelector("#confused-level");
        var confusedStep = document.querySelector("#confused-step");
        var hvgc = document.querySelector("#used-admiss");
        var hvoc = document.querySelector("#used-surgery");
        var emReceive1 = document.querySelector("#em-receive1");
        var emReceive2 = document.querySelector("#em-receive2");
        var emReceive3 = document.querySelector("#em-receive3");

     // 응급 메시지가 없을 경우: 전달 내용 X, 응급 메세지가 있을 경우: 내용 그대로 출력
    if (hospitalData[index].emReceive1 === "") {
        emReceive1.textContent = "전달 내용 X";
    } else {
        emReceive1.textContent = hospitalData[index].emReceive1;
    }

    if (hospitalData[index].emReceive2 === "") {
        emReceive2.textContent = "전달 내용 X";
    } else {
        emReceive2.textContent = hospitalData[index].emReceive2;
    }

    if (hospitalData[index].emReceive3 === "") {
        emReceive3.textContent = "전달 내용 X";
    } else {
        emReceive3.textContent = hospitalData[index].emReceive3;
    }

    // 응급실 혼잡율에 따른 confusedLevel 색 변경 및 confusedStep style 설정
    if (hospitalData[index].hvec / hospitalData[index].hperyn == 1) {
        confusedLevel.style.color = "red";
        confusedStep.textContent = "심각";
    }
      else if (hospitalData[index].hvec / hospitalData[index].hperyn > 0.8 && hospitalData[index].hvec / hospitalData[index].hperyn < 1) {
        confusedLevel.style.color = "green";
        confusedStep.textContent = "여유";
    } else if (hospitalData[index].hvec / hospitalData[index].hperyn > 0.5 && hospitalData[index].hvec / hospitalData[index].hperyn < 0.79) {
        confusedLevel.style.color = "orange";
        confusedStep.textContent = "보통";
    } else {
        confusedLevel.style.color = "red";
        confusedStep.textContent = "심각";
    }

    // 병원 이름, 입원실과 수술실의 가용 병상 수 표시
    hospitalName.textContent = hospitalData[index].name;
    hvgc.textContent = hospitalData[index].hvgc;
    hvgc.style.fontWeight = 'bold';
    hvoc.textContent = hospitalData[index].hvoc;
    hvoc.style.fontWeight = 'bold';

    // confusedStep style 설정
    confusedStep.style.fontWeight = "bold";
    confusedStep.style.color = confusedLevel.style.color;
    }

    var myChart;

    function drawChart(index) {
        var emergencyRoom = hospitalData[index].hperyn - hospitalData[index].hvec;

        if(emergencyRoom ==0) {
            emergencyRoom = hospitalData[index].hvec;
        }

        var data = {
            labels: ['대기 환자', '기존 병상수'],
            datasets: [{
                label: '(응급실)대기 환자/기존 병상수',
                data: [emergencyRoom, hospitalData[index].hperyn],
                backgroundColor: ['red', 'green'],
            }]
        };

        var ctx = document.getElementById('statusChart').getContext('2d');

        // 이전 차트 파괴
        if (myChart) {
            myChart.destroy();
        }

        // 새로운 차트 생성
        myChart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {}
        });
    }
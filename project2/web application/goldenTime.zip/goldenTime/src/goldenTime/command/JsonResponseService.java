package goldenTime.command;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import goldenTime.dto.CongestionDto;
import goldenTime.dto.EMNumberDto;

public class JsonResponseService implements EmrCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        JSONObject json = new JSONObject();

        ArrayList<CongestionDto> congestList = (ArrayList<CongestionDto>) request.getAttribute("congestionList");
        ArrayList<EMNumberDto> emNumList = (ArrayList<EMNumberDto>) request.getAttribute("emNumberList");

        json.put("congestData", congestList);
        json.put("emNumData", emNumList);        

        try (PrintWriter out = response.getWriter()) {
            out.print(json.toString());
            out.flush(); // 버퍼를 비우고 즉시 클라이언트에게 보냄
        } catch (IOException e) {
            e.printStackTrace();
        }

	}

}

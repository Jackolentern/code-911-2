package goldenTime.command;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goldenTime.dao.EmrDao;
import goldenTime.dto.EMNumberDto;

public class EmNumberListCommand implements EmrCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		EmrDao dao = new EmrDao();
		ArrayList<EMNumberDto> dtos = dao.emNumberList();
		request.setAttribute("emNumberList", dtos);
	}

}

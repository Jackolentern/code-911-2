package goldenTime.dto;

public class EMNumberDto {
	private int year;
	private int needEm;
	private int actualEm;
	
	public EMNumberDto() {
		
	}
	
	public EMNumberDto(int year, int needEm, int actualEm) {
		this.year = year;
		this.needEm = needEm;
		this.actualEm = actualEm;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getNeedEm() {
		return needEm;
	}

	public void setNeedEm(int needEm) {
		this.needEm = needEm;
	}

	public int getActualEm() {
		return actualEm;
	}

	public void setActualEm(int actualEm) {
		this.actualEm = actualEm;
	}
	
	


}

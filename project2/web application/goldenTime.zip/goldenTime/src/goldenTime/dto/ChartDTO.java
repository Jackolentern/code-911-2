package goldenTime.dto;

public class ChartDTO {
	
	private String region;
	private float within60;
	private float inside;
	private float within30;
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public float getWithin60() {
		return within60;
	}
	public void setWithin60(float within60) {
		this.within60 = within60;
	}
	public float getInside() {
		return inside;
	}
	public void setInside(float inside) {
		this.inside = inside;
	}
	public float getWithin30() {
		return within30;
	}
	public void setWithin30(float within30) {
		this.within30 = within30;
	}
	
	

}

package goldenTime.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import goldenTime.dto.CongestionDto;
import goldenTime.dto.EMNumberDto;


public class EmrDao {
	DataSource dataSource;
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public EmrDao() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<CongestionDto> congestionList() {
		ArrayList<CongestionDto> dtos = new ArrayList<CongestionDto>();
		conn = null;
		pstmt = null;
		rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select * from emcongestion";
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int year = rs.getInt("year");
				int congestion = rs.getInt("congestion");
				
				CongestionDto dto = new CongestionDto(year,congestion);
				dtos.add(dto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	
	public ArrayList<EMNumberDto> emNumberList() {
		ArrayList<EMNumberDto> dtos = new ArrayList<EMNumberDto>();
		conn = null;
		pstmt = null;
		rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select * from emnumber";
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int year = rs.getInt("year");
				int needEm = rs.getInt("needEm");
				int actualEm = rs.getInt("actualEm");
				
				EMNumberDto dto = new EMNumberDto(year, needEm, actualEm);
				dtos.add(dto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	

}

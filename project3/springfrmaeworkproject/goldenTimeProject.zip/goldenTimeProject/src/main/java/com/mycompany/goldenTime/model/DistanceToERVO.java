package com.mycompany.goldenTime.model;

import org.springframework.stereotype.Component;

@Component
public class DistanceToERVO {
	
	private String title;
    private Double distance;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Double getDistance() {
		return distance;
	}
	public void setDistance(Double distance) {
		this.distance = distance;
	}

    

}


package com.mycompany.goldenTime.service;

import org.springframework.stereotype.Component;

@Component
public class CService {
	
	
	

}

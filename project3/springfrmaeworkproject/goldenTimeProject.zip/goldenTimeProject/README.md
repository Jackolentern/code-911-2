# <center> 응급실 혼잡도 분석을 통한 의료 서비스 극대화 </center>
<center>효율적인 의료서비스 제공과 응급실 과밀화 해결을 위한<br></center>   
<center>응급실 혼잡도 예측 웹 사이트, GoldenTime 입니다.</center>

   
## 프로젝트 개요
* 프로젝트 이름 : GoldenTime
* 프로젝트 기간
  + 1차 프로젝트(UI개발) : 2023.11.15 - 2023.12.18
  + 2차 프로젝트(기능 구현) : 2024.01.15 - 2024.02.02

   
## 개발환경
-	언어 : JAVA
-	UI : HTML5, CSS, JavaScript, jQuery, Bootstrap
-	DB : Oracle
-	Data 분석 : R
-	Framework : Spring Framework
-	Server : Apache Tomcat 9
-	기타 사용 기술 : RestAPI , Chart.js
